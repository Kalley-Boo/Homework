package com.company.oop.agency.models.contracts;

public interface Identifiable {

    int getId();

}
