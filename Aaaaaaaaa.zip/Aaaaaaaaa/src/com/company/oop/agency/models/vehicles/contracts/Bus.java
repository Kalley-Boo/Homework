package com.company.oop.agency.models.vehicles.contracts;

public interface Bus extends Vehicle{

}