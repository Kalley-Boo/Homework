package com.company.oop.agency.models.vehicles;

public enum VehicleType {
    LAND, AIR, SEA
}
