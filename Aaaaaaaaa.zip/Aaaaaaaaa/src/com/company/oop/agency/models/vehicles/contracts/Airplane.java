package com.company.oop.agency.models.vehicles.contracts;

public interface Airplane extends Vehicle{

    boolean hasFreeFood();

}