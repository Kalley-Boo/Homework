package com.company.oop.agency.core.contracts;

public interface Engine {

    void start();

}